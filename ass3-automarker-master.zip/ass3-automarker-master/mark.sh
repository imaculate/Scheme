#!/bin/bash          
gsi automarker/automarker.scm automarker/spec.scm assignment3.scm
